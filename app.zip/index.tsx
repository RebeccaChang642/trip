// Logic is contained in index.html for Single File App requirement.
console.log("App running in Single File Mode (index.html)");
